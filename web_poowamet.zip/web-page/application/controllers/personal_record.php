<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class personal_record extends CI_Controller {
    public function index()
    {
        $this->load->view('mycss');
        $this->load->view('myjs');
        $this->load->view('personal_record');
    }

}