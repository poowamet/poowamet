<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Web poowamet</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="<?php echo base_url('assets');?>/img/favicon.png" rel="icon">
  <link href="<?php echo base_url('assets');?>/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo base_url('assets');?>/vendor/aos/aos.css" rel="stylesheet">
  <link href="<?php echo base_url('assets');?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo base_url('assets');?>/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="<?php echo base_url('assets');?>/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="<?php echo base_url('assets');?>/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="<?php echo base_url('assets');?>/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="<?php echo base_url('assets');?>/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="<?php echo base_url('assets');?>/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Arsha - v4.9.0
  ======================================================== -->
</head>

<header id="header" class="fixed-top">
    <div class="container d-flex align-items-center">
      <h1 class="logo me-auto"><a href="index.html">Homepage</a></h1>
      <nav id="navbar" class="navbar" >
        <ul>
          <li><a class="nav-link scrollto active" href="<?php echo site_url('Mypage');?>">Homepage</a></li>
          <li><a class="getstarted scrollto" href="<?php echo site_url('personal_record');?>">About me</a></li>
          <li><a class="getstarted scrollto" href="<?php echo site_url('academic_works');?>">academic work</a></li>
          <li><a class="getstarted scrollto" href="<?php echo site_url('activity');?>">activity</a></li>
          <li><a class="getstarted scrollto" href="<?php echo site_url('contact_information');?>">contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header>
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1 aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
          <h1>ยินดีต้อนรับสู้เว็บเพจ poowamet</h1>
          <div class="d-flex justify-content-center justify-content-lg-start">
            <a href="<?php echo site_url('Mypage');?>" class="btn-get-started scrollto">Les't go</a>
            <a target="_blank" href="https://www.youtube.com/watch?v=cupFejAvgPU&t" class="glightbox btn-watch-video"><i class="bi bi-play-circle"></i><span>Watch my first Video</span></a>
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2 hero-img aos-init aos-animate" data-aos="zoom-in" data-aos-delay="200">
          <img src="<?php echo base_url('assets');?>/img/ben.PNG" class="img-fluid animated" alt="">
        </div>
      </div>
    </div>

  </section>

  <section id="hero" class="d-flex align-items-center">
      <div class="container">

        <div class="row aos-animate" data-aos="zoom-in">

          <div class="d-flex align-items-center justify-content-center">
            <img src="<?php echo base_url('assets');?>/img/rain.gif">
          </div>

        </div>

      </div>
    </section>

    